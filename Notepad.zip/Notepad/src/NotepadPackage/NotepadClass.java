package NotepadPackage;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.print.PrinterException;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.filechooser.FileNameExtensionFilter;

public class NotepadClass {

	private static JFrame frame = new JFrame("");
	public static JTextArea textArea;
	private static File currentFile;
	public static SecretKey secretKey1;

	static {
		try {
			Toolkit t = Toolkit.getDefaultToolkit();
			Dimension d = t.getScreenSize();
			int widthW = (int) (d.getWidth() * 0.3);
			int heightH = (int) (d.getHeight() * 0.5);
			frame.setSize(widthW, heightH);
			frame.setLocationRelativeTo(null);

			try {
				File keyFile1 = new File("C:/keys/aes.key");

				if (keyFile1.exists()) {
					System.out.println("Chave AES já existe. Não será gerada uma nova chave.");
					try (FileInputStream fis1 = new FileInputStream(keyFile1)) {
						byte[] keyBytes = new byte[fis1.available()];
						fis1.read(keyBytes);
						secretKey1 = new SecretKeySpec(keyBytes, "AES");
					}
				} else {
					// Gerar uma chave AES de 256 bits
					KeyGenerator keyGen1 = KeyGenerator.getInstance("AES");
					keyGen1.init(256, new SecureRandom());
					secretKey1 = keyGen1.generateKey();

					// Salvar a chave em um arquivo
					keyFile1.getParentFile().mkdirs(); // Certifique-se de que o diretório existe
					try (FileOutputStream fos1 = new FileOutputStream(keyFile1)) {
						fos1.write(secretKey1.getEncoded());
					}

					System.out.println("Chave AES gerada e armazenada com sucesso.");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}

	public NotepadClass() {
		frame.setTitle("Loading...");
		frame.setVisible(true);
		textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setFont(new Font("Times New Roman", Font.BOLD, 25));
		frame.add(new JScrollPane(textArea), BorderLayout.CENTER);

		JMenuBar menuBar = new JMenuBar();
		JMenu fileMenu = new JMenu("File");

		JMenuItem newWindowItem = new JMenuItem("New Window");
		newWindowItem.addActionListener(e -> new NotepadClass());
		fileMenu.add(newWindowItem);

		JMenuItem newItem = new JMenuItem("New");
		newItem.addActionListener(e -> {
			textArea.setText("");
			currentFile = null;
			updateTitle();
		});
		fileMenu.add(newItem);

		fileMenu.addSeparator();

		JMenuItem loadItem = new JMenuItem("Load");
		loadItem.addActionListener(new LoadFileAction());
		fileMenu.add(loadItem);

		fileMenu.addSeparator();

		JMenuItem saveItem = new JMenuItem("Save");
		saveItem.addActionListener(new SaveFileAction());
		fileMenu.add(saveItem);

		JMenuItem saveAsItem = new JMenuItem("Save as");
		saveAsItem.addActionListener(new SaveAsFileAction());
		fileMenu.add(saveAsItem);

		fileMenu.addSeparator();

		JMenuItem printItem = new JMenuItem("Print");
		printItem.addActionListener(e -> {
			try {
				if (!textArea.getText().trim().equals("")) {
					textArea.print();
				}
			} catch (PrinterException printerException) {
				printerException.printStackTrace();
			}
		});
		fileMenu.add(printItem);

		fileMenu.addSeparator();

		JMenuItem exitItem = new JMenuItem("Exit");
		exitItem.addActionListener(e -> {
			if (confirmExit()) {
				System.exit(0);
			}
		});
		fileMenu.add(exitItem);

		menuBar.add(fileMenu);
		frame.setJMenuBar(menuBar);

		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				if (confirmExit()) {
					frame.dispose();
				}
			}
		});
		frame.setTitle("Vicenze´s Secure Notepad Definitive Stable - New File");
	}

	private boolean confirmExit() {
		int option = JOptionPane.showConfirmDialog(frame,
				"You have unsaved changes. Do you want to save them before exiting?", "Confirm Exit",
				JOptionPane.YES_NO_CANCEL_OPTION);

		if (option == JOptionPane.YES_OPTION) {
			if (!textArea.getText().trim().equals("")) {
				new SaveAsFileThread().start();
			}
		} else if (option == JOptionPane.NO_OPTION) {
			return true; // Proceed with exit
		} else {
			return false; // Cancel exit
		}
		return false;
	}

	private static void updateTitle() {
		String title = "Vicenze´s Secure Notepad Release Version 3.1 Stable";
		if (currentFile != null) {
			title += " - " + currentFile.getName();
		} else {
			title += " - New File";
		}
		frame.setTitle(title);
	}

	private static byte[] encrypt(String plainText) throws Exception {
		try {
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey1);
			return cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
		} catch (Exception error) {
			JOptionPane.showMessageDialog(null, "Error ao salvar o texto, erro de criptografia");
		}
		return null;
	}

	private static String decrypt(byte[] cipherText) throws Exception {
		try {
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, secretKey1);
			byte[] decryptedBytes = cipher.doFinal(cipherText);
			return new String(decryptedBytes, StandardCharsets.UTF_8);
		} catch (Exception error) {
			JOptionPane.showMessageDialog(null, "Error ao ler o texto, erro de descriptografia");
		}
		return null;
	}

	private class LoadFileAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			new LoadFileThread().start();
		}
	}

	private class LoadFileThread extends Thread {
	    @Override
	    public void run() {
	        try {
	            JFileChooser fileChooser = new JFileChooser();
	            fileChooser.setFileFilter(new FileNameExtensionFilter("Text Files", "txt"));
	            int returnValue = fileChooser.showOpenDialog(null);
	            if (returnValue == JFileChooser.APPROVE_OPTION) {
	                currentFile = fileChooser.getSelectedFile();
	                updateTitle();
	                new SwingWorker<Void, Void>() {
	                    @Override
	                    protected Void doInBackground() {
	                        try (FileInputStream fis = new FileInputStream(currentFile);
	                             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

	                            byte[] buffer = new byte[1024];
	                            int bytesRead;
	                            while ((bytesRead = fis.read(buffer)) != -1) {
	                                baos.write(buffer, 0, bytesRead);
	                            }
	                            byte[] encryptedText = baos.toByteArray();

	                            try {
	                                String text = decrypt(encryptedText);
	                                textArea.setText(text);
	                            } catch (Exception ex) {
	                                // Melhorar a mensagem de erro para a descriptografia
	                                JOptionPane.showMessageDialog(null, 
	                                    "Error decrypting the file. The file may be corrupted or not properly encrypted.",
	                                    "Decryption Error",
	                                    JOptionPane.ERROR_MESSAGE);
	                                ex.printStackTrace();
	                            }
	                        } catch (Exception ex) {
	                            // Melhorar a mensagem de erro para o carregamento do arquivo
	                            JOptionPane.showMessageDialog(null, 
	                                "Error loading the file. Please ensure the file is not corrupted and is accessible.",
	                                "File Load Error",
	                                JOptionPane.ERROR_MESSAGE);
	                            ex.printStackTrace();
	                        }
	                        return null;
	                    }
	                }.execute();
	            }
	        } catch (Exception ex) {
	            // Melhorar a mensagem de erro para o erro geral de carregamento
	            JOptionPane.showMessageDialog(null, 
	                "An unexpected error occurred while trying to load the file.",
	                "Unexpected Error",
	                JOptionPane.ERROR_MESSAGE);
	            ex.printStackTrace();
	        }
	    }
	}


	private class SaveFileAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			new SaveFileThread().start();
		}
	}

	private class SaveFileThread extends Thread {
		@Override
		public void run() {
			try {
				if (currentFile != null) {
					try (FileOutputStream fos = new FileOutputStream(currentFile)) {
						String text = textArea.getText().trim();
						if (!text.isEmpty()) {
							byte[] encryptedText = encrypt(text);
							fos.write(encryptedText);
							updateTitle();
						}
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "Error encrypting file");
						ex.printStackTrace();
					}
				} else {
					new SaveAsFileAction().actionPerformed(null);
				}
			} catch (Exception Error) {
				System.out.println("Erro master Save");
			}
		}
	}

	private class SaveAsFileAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			new SaveAsFileThread().start();
		}
	}

	private class SaveAsFileThread extends Thread {
	    @Override
	    public void run() {
	        try {
	            JFileChooser fileChooser = new JFileChooser();
	            fileChooser.setFileFilter(new FileNameExtensionFilter("Text Files", "txt"));
	            int returnValue = fileChooser.showSaveDialog(null);
	            if (returnValue == JFileChooser.APPROVE_OPTION) {
	                File file = fileChooser.getSelectedFile();
	                
	                // Verifique se o arquivo tem a extensão ".txt"
	                String filePath = file.getAbsolutePath();
	                if (!filePath.toLowerCase().endsWith(".txt")) {
	                    file = new File(filePath + ".txt");
	                }

	                // Salve o arquivo com a extensão correta
	                try (FileOutputStream fos = new FileOutputStream(file)) {
	                    String text = textArea.getText().trim();
	                    if (!text.isEmpty()) {
	                        byte[] encryptedText = encrypt(text);
	                        fos.write(encryptedText);
	                        currentFile = file; // Atualize o arquivo atual
	                        updateTitle();
	                    }
	                    JOptionPane.showMessageDialog(null, "The file have been saved");
	                } catch (Exception ex) {
	                    JOptionPane.showMessageDialog(null, "Error encrypting file");
	                    ex.printStackTrace();
	                }
	            }
	        } catch (Exception Error) {
	           JOptionPane.showMessageDialog(null, "Error in SaveAsFileThread");
	        }
	    }
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new NotepadClass());
	}
}
